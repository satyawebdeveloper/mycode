<?php




class PayFlow {
	public $user;
	public $vendor;
	public $partner;
	public $pwd;
	public $endpoint;
	public $amount;
	
	
	//log
	public $orderid;
	public $firstname;
	public $lastname;
	public $phone;
	public $orderdate;
	public $payment_status;
	public $securetoken;
	public $securetokenid;
	public $street;
	public $username;
	public $city;
	public $state;
	public $zip;
	public $country;
	public $email;
	
	
	
	
	

	
	public function __construct($user, $vendor, $partner, $pwd, $endpoint,$amount) {
		$this->user = $user;
		$this->vendor = $vendor;
		$this->partner = $partner;
		$this->pwd = $pwd;
		$this->endpoint = $endpoint;
		$this->amount = $amount;
	}
	
	/*
	 * getSecureToken() This function sets the values for the *secureTokenID, invoice number, and assigns other variables as needed for the call this uses hard coded values for example purposes. * @return array $response
	 */
	public function getSecureToken() { 
		//create a SECURETOKENID
		$secureTokenID = $this->guid (); // create a unique INVNUM
		$invnum = "INV" . $this->guid ();
		//$reqstr = "&TRXTYPE=A&" . "TENDER=C&" . "INVNUM=" . $invnum . "&AMT=25.00&" . "CURRENCY=USD&" . "PONUM=123456&" . "STREET=111 Main St&" . "NAME=Test Testerson&" . "CITY=Omaha&" . "STATE=NE&" . "ZIP=68112&" . "COUNTRY=US&" . "EMAIL=test@test.com&" . "PHONE=4025555555&" . "CREATESECURETOKEN=Y&" . "VERBOSITY=HIGH&" . "SECURETOKENID=" . $secureTokenID;
		//$reqstr = "&TRXTYPE=A&" . "TENDER=C&" . "INVNUM=" . $invnum . "&AMT=". $this->amount ."&" . "CURRENCY=USD&" . "PONUM=". $this->phone ."&" . "STREET=". $this->street ."&" . "NAME=". $this->firstname." ". $this->lastname ."&" ."CITY=". $this->city ."&" . "STATE=". $this->state ."&" . "ZIP=". $this->zip ."&" ."COUNTRY=". $this->country ."&" . "EMAIL=". $this->email ."&" ."PHONE=". $this->phone ."&" . "CREATESECURETOKEN=Y&" . "VERBOSITY=HIGH&" . "SECURETOKENID=" . $secureTokenID;
		
		//$reqstr = "&TRXTYPE=A&" . "TENDER=C&" . "INVNUM=" . $invnum . "&AMT=". $this->amount ."&"."CURRENCY=USD&" . "PONUM=123456&" . "STREET=111 Main St&" . "NAME=Test Testerson&" . "CITY=Omaha&" . "STATE=NE&" . "ZIP=68112&" . "COUNTRY=US&" . "EMAIL=test@test.com&" . "PHONE=4025555555&" . "CREATESECURETOKEN=Y&" . "VERBOSITY=HIGH&" . "SECURETOKENID=" . $secureTokenID;
		$reqstr = "&TRXTYPE=A&" . "TENDER=&" . "INVNUM=" . $invnum . "&AMT=". $this->amount ."&"."CURRENCY=USD&" . "PONUM=&" . "STREET=&" . "NAME=&" . "CITY=&" . "STATE=&" . "ZIP=&" . "COUNTRY=US&" . "EMAIL=&" . "PHONE=&" . "CREATESECURETOKEN=Y&" . "VERBOSITY=HIGH&" . "SECURETOKENID=" . $secureTokenID;
		$credstr = "USER=" . $this->user . "&VENDOR=" . $this->vendor . "&PARTNER=" . $this->partner . "&PWD=" . $this->pwd;
	
		//combine the strings
		$nvp_req = $credstr . $reqstr;
		
		//set the endpoint to a local var:
		$endpoint = $this->endpoint;
		
		//make the call
		$response = $this->PPHttpPost ( $endpoint, $nvp_req );
		return $response;
	}
	
	// end getToken call
	
	/*
	 * PPHttpPost(string, string) * PPHttpPost takes in two strings, and *makes a curl request and returns the result. @return array $httpResponseAr
	 */
	public function PPHttpPost($endpoint, $nvpstr) {
		// setting the curl parameters.
		$ch = curl_init ();
		curl_setopt ( $ch, CURLOPT_URL, $endpoint );
		curl_setopt ( $ch, CURLOPT_VERBOSE, 1 );
		// turning off the server and peer verification(TrustManager Concept).
		curl_setopt ( $ch, CURLOPT_SSL_VERIFYPEER, FALSE );
		curl_setopt ( $ch, CURLOPT_SSL_VERIFYHOST, FALSE );
		curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, 1 );
		curl_setopt ( $ch, CURLOPT_POST, 1 );
		// setting the NVP $my_api_str as POST FIELD to curl
		curl_setopt ( $ch, CURLOPT_POSTFIELDS, $nvpstr );
		// getting response from server
		$httpResponse = curl_exec ( $ch );
		
		if (! $httpResponse) {
			$response = "API_method failed: " . curl_error ( $ch ) . '(' . curl_errno ( $ch ) . ')';
			return $response;
		}
		$httpResponseAr = explode ( "&", $httpResponse );
		return $httpResponseAr;
	} // end PPHttpPost function
	
	/*
	 * getMySecureToken(array) * This takes in the response array from the PPHttpPost call, and parses out the SecureToken * This is used because the securetoken may contain *an "=" sign * @return string $secure_token
	 */
	public function getMySecureToken($response) {
		$secure_token = $response [1];
		$secure_token = substr ( $secure_token, - 25 );
		return $secure_token;
	}
	// end getSecureToken()
	
	/*
	 * parseResponse(array) * This function parses out the response without taking into account that the securetoken may contain an "=" *sign. The only thing you need from this is the *SecureTokenID. * @return array $parsed_response
	 */
	public function parseResponse($response) {
		$parsed_response = array ();
		foreach ( $response as $i => $value ) {
			$tmpAr = explode ( "=", $value );
			if (sizeof ( $tmpAr ) > 1) {
				$parsed_response [$tmpAr [0]] = $tmpAr [1];
			}
		}
		return $parsed_response;
	} // end parseResponse
	
	/*
	 * getHTML(array, string) * This function dynamically builds the html code needed for the form post button. * @return string $html
	 */
	public function getHTML($response, $securetoken) {
		$html = "<form method='post' action='https://payflowlink.paypal.com/'> <input type='hidden' name='SECURETOKEN' value='$securetoken' /> <input type='hidden' name='SECURETOKENID' value='" . $response ['SECURETOKENID'] . "' /> <input type='hidden' name='MODE' value='test' /> <input type='submit' /> </form>";
		return $html;
	}
	
	

	// end getHTML
	
	/* guid() * *This function creates an MD5 hash of a timestamp *to be used with the SecureTokenID, and Invnum *in the initial call * *@return string $str */
	public function guid() { // hash out a timestamp and some chars to get a 25 char token to pass in
		$str = date ( 'l jS \of F Y h:i:s A' );
		$str = trim ( $str );
		$str = md5 ( $str );
		
		return $str;
	} // end guid
	
	
	
	public function log_payflow(){
		$nid = db_insert('paypal_payflow_log') 
		->fields(array(
				'orderid' => $this->orderid,
				'firstname' => $this->firstname,
				'lastname' => $this->lastname,
				'phone' => $this->phone,
				'orderdate' => $this->orderdate,
				'payment_status' => $this->payment_status,
				'amount' => $this->amount,
				'securetoken' => $this->securetoken,
				'securetokenid' => $this->securetokenid,
				
		))
		->execute();
		
	}
}//end class
	
  


